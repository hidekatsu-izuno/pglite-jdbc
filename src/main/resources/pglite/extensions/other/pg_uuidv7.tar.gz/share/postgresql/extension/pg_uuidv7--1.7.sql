CREATE FUNCTION uuid_generate_v7()
RETURNS uuid
AS 'MODULE_PATHNAME', 'uuid_generate_v7'
VOLATILE STRICT LANGUAGE C PARALLEL SAFE;

CREATE FUNCTION uuid_v7_to_timestamptz(uuid)
RETURNS timestamptz
AS 'MODULE_PATHNAME', 'uuid_v7_to_timestamptz'
STABLE STRICT LANGUAGE C PARALLEL SAFE;

CREATE FUNCTION uuid_timestamptz_to_v7(timestamptz, zero bool = false)
RETURNS uuid
AS 'MODULE_PATHNAME', 'uuid_timestamptz_to_v7'
STABLE STRICT LANGUAGE C PARALLEL SAFE;

CREATE FUNCTION uuid_v7_to_timestamp(uuid)
RETURNS timestamp
AS 'MODULE_PATHNAME', 'uuid_v7_to_timestamp'
STABLE STRICT LANGUAGE C PARALLEL SAFE;

CREATE FUNCTION uuid_timestamp_to_v7(timestamp, zero bool = false)
RETURNS uuid
AS 'MODULE_PATHNAME', 'uuid_timestamp_to_v7'
STABLE STRICT LANGUAGE C PARALLEL SAFE;
