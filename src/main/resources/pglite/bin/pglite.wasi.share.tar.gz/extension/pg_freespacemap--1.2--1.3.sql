/* contrib/pg_freespacemap/pg_freespacemap--1.2--1.3.sql */

CREATE OR REPLACE FUNCTION
  pg_freespace(rel regclass, blkno OUT bigint, avail OUT int2)
RETURNS SETOF RECORD
AS 'MODULE_PATHNAME', 'pg_freespace_rel'
LANGUAGE C STRICT PARALLEL SAFE;
